/*
Dropping any temporary tables we made in the actual reporting database schema

30 October 2017, Peter Ellis
*/

DROP TABLE IDI_Sandpit.pop_exp_dev.link_person_extended
GO
