
USE IDI_Sandpit
GO

CREATE SCHEMA lib
GO


CREATE SCHEMA pop_exp_dev
GO

CREATE SCHEMA pop_exp_alpha
GO

CREATE SCHEMA pop_exp_bravo
GO

CREATE SCHEMA pop_exp_charlie
GO


CREATE SCHEMA pop_exp_sample
GO

CREATE SCHEMA intermediate
GO

CREATE SCHEMA intermediate_sample
GO