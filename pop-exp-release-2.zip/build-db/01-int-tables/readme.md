## int-tables

This folder holds SQL scripts that create tables in the "intermediate" schema.  These are tables
that don't fit into the main pop_exp schema but are basically part of ETL.  For example, a consolidated
"spells_in_nz" table which is all the time people are in New Zealand (between being born, crossing borders, and 
dying).