# Population Explorer datamart - user perspective
Peter Ellis
29 November 2017